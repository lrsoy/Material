/* 仅演示 */
$(".hover").mouseleave(
  function () {
    $(this).removeClass("hover");
  }
);