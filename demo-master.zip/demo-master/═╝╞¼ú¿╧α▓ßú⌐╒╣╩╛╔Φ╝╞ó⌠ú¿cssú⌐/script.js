/* 仅演示所需 */
$(".hover").mouseleave(
  function () {
    $(this).removeClass("hover");
  }
);